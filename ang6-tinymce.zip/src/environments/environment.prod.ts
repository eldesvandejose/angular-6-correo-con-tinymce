export const environment = {
  production: true,
  APIS_BASE: './assets/php/',
  ASSETS_URL: './assets/'
};
