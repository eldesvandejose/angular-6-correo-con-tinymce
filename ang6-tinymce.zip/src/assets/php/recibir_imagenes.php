<?php
  /* Cabeceras para evitar el CORS y para establecer la codificación.  */
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
  header('content-type: application/json; charset=utf-8');

  /*********************************************
   * Carpeta de almacenamiento de imágenes     *
   *********************************************/
  $imageFolder = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_NAME']."/assets/uploaded_images/";

  $temp = @$_FILES["file"];

  if (is_uploaded_file($temp['tmp_name'])){

    // Verificar tipo de archivo.
    if (! in_array($temp["type"], ['image/gif', 'image/jpg', 'image/jpeg', 'image/png'])) {
        header("HTTP/1.1 400 Invalid file type.");
        return;
    }

    $extension = strtolower(pathinfo($temp['name'], PATHINFO_EXTENSION));

    if (!in_array($extension, ["gif", "jpg", "png"])) {
        header("HTTP/1.1 400 Invalid extension.");
        return;
    }

    // Grabar la imagen

    $filetowrite = $imageFolder.md5(uniqid('', true)).".".$extension;
    move_uploaded_file($temp['tmp_name'], $filetowrite);

    // JSON de respuesta
    echo json_encode(['location' => $filetowrite]);
  } else {
    // Notify editor that the upload failed
    header("HTTP/1.1 500 Server Error");
  }
?>
