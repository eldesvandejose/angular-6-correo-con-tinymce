<?php
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
  header('content-type: application/json; charset=utf-8');

  // Aquí se reciben los datos, que llegan por $_POST
  // Luego se eviaría el correo, y se emite una respuesta.
  echo "";
?>
