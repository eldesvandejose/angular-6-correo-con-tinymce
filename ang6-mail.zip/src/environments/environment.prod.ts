export const environment = {
  production: true,
  APIS_BASE: './assets/',
  ASSETS_URL: './assets/'
};
