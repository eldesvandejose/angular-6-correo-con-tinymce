import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'a6m-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  public URL: string;
  public doi: string; // Enlace con el formulario
  public nombre: string; // Enlace con el formulario
  public doiIcon = 'ion-md-create';
  public nameIcon = 'ion-md-create';

  public faltanDatos = false;

  public mensaje: any;

  public paqueteDeDatos: FormData;

  constructor(public http: HttpClient) {
    this.URL = environment.APIS_BASE + 'enviar_correo.php';
  }

  public clearNotice() { }

  public checkName() {
    this.nameIcon = (this.nombre === '') ? 'ion-md-create' : 'ion-md-checkmark';
  }

  public checkDoi() {
    this.doiIcon = (this.doi === '') ? 'ion-md-create' : 'ion-md-checkmark';
  }

  public ponerMensaje(evento) {
    this.mensaje = evento;
  }

  public checkForm() {
    if (this.doi === '' || this.nombre === '' || this.mensaje.length < 6) {
      this.faltanDatos = true;
      return;
    }
    this.paqueteDeDatos = new FormData();
    this.paqueteDeDatos.append('doi', this.doi);
    this.paqueteDeDatos.append('nombre', this.nombre);
    this.paqueteDeDatos.append('mensaje', this.mensaje);
    this.sendMessage();
  }

  private sendMessage() {
    this.sendMessage$(this.paqueteDeDatos).subscribe(this.sendSuccess.bind(this), this.catchError.bind(this));
  }

  private sendMessage$(dataPack: FormData): Observable <any> {
    return this.http.post(this.URL, dataPack);
  }

  private sendSuccess() { }

  private catchError() { }

}
