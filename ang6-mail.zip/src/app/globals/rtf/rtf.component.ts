import {
  Component,
  OnInit,
  AfterViewInit,
  OnDestroy,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { environment } from '../../../environments/environment';

declare var $: any;
declare var jQuery: any;
declare var tinymce: any;

@Component({
  selector: 'a6m-rtf',
  templateUrl: './rtf.component.html',
  styleUrls: ['./rtf.component.css']
})
export class RtfComponent implements OnInit, AfterViewInit, OnDestroy {

  @Input() elementId: string;
  @Output() editorKeyup = new EventEmitter<any>();

  editor;
  private URL = environment.APIS_BASE;

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() {
    tinymce.init ({
      statusbar: false,
      height: 300,
      image_advtab: true,
      language_url: environment.ASSETS_URL + 'langs/es.js',
      language: 'es',
      selector: '#' + this.elementId,
      plugins: ['link', 'paste', 'table', 'image', 'imagetools', 'media'],
      images_upload_url: this.URL + 'php/recibir_imagenes.php',
      menubar: '',
      toolbar: 'undo redo | styleselect | bold italic | link | image media',
      skin_url: environment.ASSETS_URL + 'skins/lightgray',
      setup: editor => {
        this.editor = editor;
        editor.on('keyup change mousemove', () => {
          const content = editor.getContent();
          this.editorKeyup.emit(content);
        });
      },
    });
  }

  ngOnDestroy () {
    tinymce.remove(this.editor);
  }

}
