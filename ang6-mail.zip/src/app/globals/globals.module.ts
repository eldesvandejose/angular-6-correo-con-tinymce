import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RtfComponent } from './rtf/rtf.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [RtfComponent],
  exports: [RtfComponent]
})
export class GlobalsModule { }
